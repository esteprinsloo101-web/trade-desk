# Day-cash / pipeline (quick)

1. Keep each chase linked to the **exact** WhatsApp / bank / supplier URL you already use.
2. Run **New quote → Deposit chase → Job day → Invoice** as ProcessRunner stages — don’t rebuild the list.
3. Log day cash in Money; Export JSON after a clean week.
4. Humans Approve deposit log and invoice issue — the app prepares only.
5. Toggle unused modules in Settings.
