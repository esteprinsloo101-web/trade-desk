# Trade Desk — unlock pack

**Faceless Plain Desk** · soft-launch unlock (suggested **R179**)

Free live demo (sample data): https://esteprinsloo101-web.github.io/trade-desk/

## What’s in this zip
- `app/` — full offline installable PWA (HTML/JS/CSS + manifest + service worker + icons)
- `SETUP.md` — open locally, Add to Home Screen, notifications, pipeline, backup
- `DISCLAIMER.md` — legal fence (read before use)
- `sample/sample-import.json` — demo-shaped sample for Import practice (replace with your own Export)
- `guides/day-cash-pipeline.md` — short tip sheet

## Soft shop note
Stokvel pack https://stofficial.gumroad.com/l/ydbgne remains the primary public CTA until first ZAR. This desk listing is a soft unlock — not a Meta/X primary steal. Garage Desk is never sellable.
